export default function Nosotros() {
    return <div className="p-10 text-wine">Nosotros</div>
  }
  