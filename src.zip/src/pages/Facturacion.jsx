export default function Facturacion() {
    return <div className="p-10 text-wine">Facturacion</div>
  }
  